from pathlib import Path
import ast,json,hashlib
R=Path('simetria_seeds')
setup=Path('demonstracoes/setup.py').read_text().split('def reconstruction_metrics')[0]
setup=setup.replace("'DEMONSTRACOES_'+", "'COBERTURA_SEEDS_'+")
# Reuse original run discovery, with checked reads, independent of prior notebook state.
full=Path('demonstracoes/setup.py').read_text();setup+='\n'+full[full.index('CAMPAIGNS='):]
setup+='''
# Nenhuma dependencia criptografica ou Go e necessaria.
import sklearn,math
from sklearn.metrics import (confusion_matrix,accuracy_score,precision_score,recall_score,f1_score,roc_auc_score,log_loss,brier_score_loss)
checks=[];last_progress_save=0.0
def gate(name,ok,detail=''):
 global last_progress_save
 checks.append({'check':name,'passed':bool(ok),'detail':str(detail)})
 if time.monotonic()-last_progress_save>15:
  dump('S08_CHECKS_PROGRESS.json',checks);last_progress_save=time.monotonic()
CLIENTS=5;THRESHOLD=0.5;FLOAT_TOL=1e-12
DAHL_FEATURES=['mean','std','min','max','median','q05','q25','q75','q95','rms','range','mean_abs_diff']
original_checked=checked
def checked(p):
 p=Path(p);assert p.resolve().is_relative_to(SNAPSHOT.resolve())
 rel=str(p.relative_to(SNAPSHOT))
 return p if rel in accessed else original_checked(p)
def sha256_file(p):
 p=checked(p);return accessed[str(p.relative_to(SNAPSHOT))]
'''
source=Path('auditoria2/fa31f18cbbe9.py').read_text();tree=ast.parse(source)
selected=['load_indices','load_dataset','sigmoid','expected_calibration_error','evaluate_independently','metrics_match']
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in selected]
class CheckedReads(ast.NodeTransformer):
 def visit_Call(self,node):
  self.generic_visit(node)
  if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and (node.func.value.id,node.func.attr) in [('np','load'),('pd','read_csv')]:node.args[0]=ast.Call(func=ast.Name(id='checked',ctx=ast.Load()),args=[node.args[0]],keywords=[])
  return node
functions=[CheckedReads().visit(n) for n in functions]
helpers=ast.unparse(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])))
extract='''# Extrair os mesmos campos em TODAS as seeds; ausencias sao falhas de cobertura.
rounds={};round_rows=[];client_rows=[];coverage=[];run_rows=[]
required=['validation','python_cpu_seconds','child_cpu_seconds','validation_probability_max_abs_difference_from_clear_round','validation_prediction_disagreement_from_clear_round','numeric_error','communication','end_to_end_round_seconds','crypto_setup_seconds','peak_rss_bytes']
for (seed,ds,sc),(folder,cfg,final) in runs.items():
 rows=[]
 for number in range(1,31):
  p=folder/'rounds'/f'round_{number:03d}_metrics.json'
  try:m=loadj(p)
  except Exception as e:
   gate(f'{seed}/{ds}/{sc}/round{number}/read',False,repr(e));continue
  gate(f'{seed}/{ds}/{sc}/round{number}/approved',m.get('approved') is True)
  gate(f'{seed}/{ds}/{sc}/round{number}/five_clients',len(m.get('clients',[]))==5)
  for key in required:
   exists=key in m and m[key] is not None
   coverage.append({'seed':seed,'dataset':ds,'scenario':sc,'round':number,'metric_group':key,'present':exists})
   if not exists:gate(f'{seed}/{ds}/{sc}/round{number}/field/{key}',False,'Missing; not zero')
  rounds[seed,ds,sc,number]=m;rows.append(m)
  # Apenas registros de instrumentacao; nao grava dados ou pesos individuais.
  record={k:v for k,v in m.items() if k!='clients'};record['seed']=seed
  round_rows.append(record)
  for cid,c in enumerate(m.get('clients',[])):client_rows.append(dict(c,seed=seed,dataset=ds,scenario=sc,round=number,client=cid))
 gate(f'{seed}/{ds}/{sc}/30rounds',len(rows)==30)
 if len(rows)==30:
  total=sum(float(x['end_to_end_round_seconds']) for x in rows)
  recorded=final['measurement_summary']['total_end_to_end_seconds']
  gate(f'{seed}/{ds}/{sc}/endtoend_sum',abs(total-recorded)<=1e-8,f'{total} vs {recorded}')
  cpu=sum(float(x.get('python_cpu_seconds',0))+float(x.get('child_cpu_seconds',0)) for x in rows) if all('python_cpu_seconds' in x and 'child_cpu_seconds' in x for x in rows) else None
  run_rows.append({'seed':seed,'dataset':ds,'scenario':sc,'python_cpu_seconds_sum':sum(x['python_cpu_seconds'] for x in rows) if all('python_cpu_seconds'in x for x in rows) else None,
   'child_cpu_seconds_sum':sum(x['child_cpu_seconds'] for x in rows) if all('child_cpu_seconds'in x for x in rows) else None,'total_cpu_seconds_sum':cpu,'end_to_end_seconds_sum':total,
   'online_seconds_sum':sum(x['online_round_seconds'] for x in rows),'reported_setup_or_external_residual_seconds_sum':sum(x['crypto_setup_seconds'] for x in rows),
   'online_bytes_sum':sum(x['communication']['online_bytes'] for x in rows),'peak_rss_bytes':max(x['peak_rss_bytes'] for x in rows)})
pd.json_normalize(round_rows).to_csv(OUT/'S08_ALL_ROUND_FIELDS_810.csv',index=False)
pd.json_normalize(client_rows).to_csv(OUT/'S08_CLIENT_INSTRUMENTATION_4050.csv',index=False)
tab('S08_FIELD_COVERAGE.csv',coverage);tab('S08_RUN_CPU_COSTS_27.csv',run_rows)
# Variacoes temporais e contagens vs Baseline da mesma seed.
variation=[];gains=[]
for seed in [42,123,2026]:
 for ds in ['PHYSIONET_CHALLENGE_2012','DAHL_RATS','CHEXCHONET']:
  for sc in ['BASELINE','CKKS','HYBRID']:
   row={'seed':seed,'dataset':ds,'scenario':sc};pairs=[]
   for number in range(1,31):
    m=rounds.get((seed,ds,sc,number));b=rounds.get((seed,ds,'BASELINE',number));first=rounds.get((seed,ds,sc,1))
    if m and b and first:
     pairs.append((m,b));gains.append({'seed':seed,'dataset':ds,'scenario':sc,'round':number,
      **{'validation_'+k+'_gain_vs_round1':m['validation'][k]-first['validation'][k] for k in ['accuracy','precision','recall','f1','auroc']},
      **{'validation_'+k+'_delta_vs_baseline':m['validation'][k]-b['validation'][k] for k in ['accuracy','precision','recall','f1','auroc']}})
   row['paired_rounds']=len(pairs)
   for k in ['accuracy','precision','recall','f1','auroc']:row[k+'_different_rounds']=sum(m['validation'][k]!=b['validation'][k] for m,b in pairs)
   row['max_probability_difference_from_clear_round']=max((m['validation_probability_max_abs_difference_from_clear_round'] for m,b in pairs),default=None)
   variation.append(row)
tab('S08_TEMPORAL_GAINS_AND_DELTAS_810.csv',gains);tab('S08_VARIATION_COUNTS_27.csv',variation)
print('Extracao concluida. Cobertura por campo:',len(coverage),'registros.')
'''
recalculate='''# Checkpoints e dados congelados: mesmas definicoes da Fase22; SEM TREINAMENTO.
# Recalcula teste final somente para auditoria/metricas complementares. Nao ajusta modelo nem threshold.
recalculated=[];numeric=[];state_rows=[];datafiles={'PHYSIONET_CHALLENGE_2012':'physionet_challenge_2012_features.csv','DAHL_RATS':'dahl_derived_features.csv','CHEXCHONET':'chexchonet_embeddings.npz'}
for ds,filename in datafiles.items():
 print('Processando freeze e checkpoints:',ds,flush=True)
 ref=runs[42,ds,'BASELINE'][1];choices=[]
 for path in (SNAPSHOT/'campaign').glob('*/01_DATASET_FREEZE/'+ds+'/SCIENTIFIC_FREEZE/'+filename):
  if sha256_file(path)==ref['data_sha256']:choices.append(path.parent.parent.parent)
 if not choices:
  gate(ds+'/freeze',False,'No verified matching freeze');continue
 root=choices[0]
 try:data=load_dataset(root,ds,ref)
 except Exception as e:
  gate(ds+'/load_dataset',False,repr(e));continue
 for seed in [42,123,2026]:
  P={};states={};preds={};MM={}
  for sc in ['BASELINE','CKKS','HYBRID']:
   folder,cfg,final=runs[seed,ds,sc]
   hashes=all(cfg[k]==ref[k] for k in ['data_sha256','partition_sha256','preprocessing_sha256','initial_state_sha256'])
   gate(f'{seed}/{ds}/{sc}/common_frozen_inputs',hashes)
   if not hashes:continue
   try:
    for number in range(0,31):
     cp=checked(folder/'checkpoints'/f'state_round_{number:03d}.npy')
     state=np.asarray(np.load(cp,allow_pickle=False),np.float64).reshape(-1)
     assert state.shape==(cfg['parameter_count'],) and np.isfinite(state).all()
     baseline=checked(runs[seed,ds,'BASELINE'][0]/'checkpoints'/f'state_round_{number:03d}.npy')
     bs=np.asarray(np.load(baseline,allow_pickle=False),np.float64).reshape(-1)
     delta=state-bs
     state_rows.append({'seed':seed,'dataset':ds,'scenario':sc,'round':number,'state_max_abs_difference':float(np.max(np.abs(delta))),'state_l2_difference':float(np.linalg.norm(delta))})
    assert sha(cp)==final['final_state_sha256'],'Final checkpoint hash differs from FINAL_RESULT'
    states[sc]=state
    for split in ['validation','test']:
     metrics,probs,pred=evaluate_independently(state,data['X'],data['y'],data[split])
     match=metrics_match(metrics,final[split]);gate(f'{seed}/{ds}/{sc}/{split}/recalculated',match,'Tolerance 1e-12 and exact confusion counts')
     recalculated.append(dict(metrics,seed=seed,dataset=ds,scenario=sc,split=split,recorded_metrics_match=match))
     if split=='test':P[sc]=probs;preds[sc]=pred;MM[sc]=metrics
   except Exception as e:gate(f'{seed}/{ds}/{sc}/recalculation',False,repr(e))
  if 'BASELINE' not in P:continue
  for sc in P:
   delta=P[sc]-P['BASELINE'];sd=states[sc]-states['BASELINE']
   ranka=pd.Series(P['BASELINE']).rank(method='average').to_numpy();rankb=pd.Series(P[sc]).rank(method='average').to_numpy()
   corr=float(np.corrcoef(ranka,rankb)[0,1]) if np.std(ranka)>0 and np.std(rankb)>0 else None
   numeric.append({'seed':seed,'dataset':ds,'scenario':sc,'reference':'BASELINE',
    'state_max_abs_difference':float(np.max(np.abs(sd))),'state_l2_difference':float(np.linalg.norm(sd)),
    'probability_max_abs_difference':float(np.max(np.abs(delta))),'probability_mean_abs_difference':float(np.mean(np.abs(delta))),'probability_l2_difference':float(np.linalg.norm(delta)),
    'prediction_disagreement_count':int(np.sum(preds[sc]!=preds['BASELINE'])),'prediction_disagreement_rate':float(np.mean(preds[sc]!=preds['BASELINE'])),
    'rank_correlation':corr,**{'test_'+k+'_delta':MM[sc][k]-MM['BASELINE'][k] for k in ['accuracy','precision','recall','f1','auroc','log_loss','brier_score','ece_10_bins']}})
 del data
 tab('S08_RECALCULATED_FINAL_METRICS_54.csv',recalculated);tab('S08_CONTINUOUS_DELTAS_27.csv',numeric);tab('S08_CHECKPOINT_DELTAS_837.csv',state_rows)
print('Recalculo concluido. Nenhuma probabilidade individual ou dado bruto foi exportado.')
'''
finish='''# Gate de simetria e integridade; falhas nao sao substituidas por zeros.
for rel,before in accessed.items():gate('integrity/'+rel,sha(SNAPSHOT/rel)==before)
for seed in [42,123,2026]:
 gate(str(seed)+'/round_records',sum(r.get('seed')==seed for r in round_rows)==270)
 gate(str(seed)+'/client_records',sum(r.get('seed')==seed for r in client_rows)==1350)
 gate(str(seed)+'/recalculated_final_metrics',sum(r['seed']==seed for r in recalculated)==18)
 gate(str(seed)+'/continuous_deltas',sum(r['seed']==seed for r in numeric)==9)
 gate(str(seed)+'/checkpoints',sum(r['seed']==seed for r in state_rows)==279)
gate('metric_group_coverage',all(r['present'] for r in coverage) and len(coverage)==810*len(required))
dump('S08_CHECKS_PROGRESS.json',checks)
failed=[c for c in checks if not c['passed']]
dump('S08_FINAL_GATE.json',{'status':'COVERAGE_APPROVED' if not failed else 'COVERAGE_INCOMPLETE_OR_DIVERGENT',
 'failed_checks':failed,'checks_count':len(checks),'official_runs':27,'seeds':[42,123,2026],
 'raw_datasets_or_keys_exported':False,'training_executed':False,'backup_files_accessed_sha256':accessed,
 'method_source_sha256':METHOD_SOURCE_SHA256,'method':'Fase22 definitions; ECE 10 equal-width bins; sigmoid clip40; threshold0.5; float tolerance1e-12',
 'test_usage':'Posthoc audit of frozen final models only; no model/threshold tuning',
 'software':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__},
 'limitations':['No historical internal Hybrid timings inferred','No Hybrid full network setup','CPU counters are recorded sequential/process instrumentation','Structural coverage approval is not proof of security or full replay audit']})
package=OUT/'S08_Cobertura_Tres_Seeds.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():
  if p.suffix in ['.csv','.json']:z.write(p,p.name)
print('STATUS:', 'COVERAGE_APPROVED' if not failed else 'COVERAGE_INCOMPLETE_OR_DIVERGENT')
print('Falhas:',len(failed),'| Pacote:',package)
from google.colab import files
files.download(str(package))
'''
cells=[]
def md(s):cells.append({'cell_type':'markdown','metadata':{},'source':s.splitlines(True)})
def code(s):cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':s.splitlines(True)})
md('''# S08 — Cobertura equivalente das três seeds oficiais
Execute no Google Colab. Notebook independente do anterior: imports, montagem do Drive e variáveis são preparados aqui.
Requer backup S01 com BACKUP_VERIFIED. Usa somente cópias verificadas. Não instala TenSEAL/Go, não treina modelos e não executa criptografia. Gera pasta nova COBERTURA_SEEDS no repositório de segurança/resultados.
A meta é a mesma medição em cada seed, não valores iguais. Ausência/divergência impede aprovação e aparece no relatório.
O teste final é recalculado como auditoria dos modelos congelados, sem ajustar modelo, limiar ou hiperparâmetros. Não exporta atributos, labels, predições, probabilidades, chaves ou pesos.
''')
md('## 1. Preparação e backup');code(setup)
md('## 2. Definições da Fase 22');code('METHOD_SOURCE_SHA256='+repr(hashlib.sha256(source.encode()).hexdigest())+'\n'+helpers)
md('## 3. Extrair todas as rodadas e instrumentação dos clientes');code(extract)
md('## 4. Processar checkpoints e métricas contínuas');code(recalculate)
md('## 5. Verificar cobertura, integridade e baixar pacote');code(finish)
md('''## Como interpretar
COVERAGE_APPROVED exige 810 rodadas, 4.050 registros de clientes, 54 avaliações finais (validação/teste), 27 linhas de comparação contínua e 837 checkpoints (31 por run), além dos campos e hashes verificados.
As diferenças numéricas podem variar por BLAS/runtime; divergência será registrada, sem alterar dados antigos.
Envie o ZIP S08_Cobertura_Tres_Seeds.zip para gerar o próximo caderno oficial simétrico. Os cadernos e relatórios anteriores permanecem preservados. Não há pilotos neste processamento.
''')
nb={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python3','language':'python','name':'python3'},'language_info':{'name':'python'},'colab':{'name':'S08_Cobertura_Oficial_Tres_Seeds.ipynb'}},'nbformat':4,'nbformat_minor':5}
p=R/'S08_Cobertura_Oficial_Tres_Seeds.ipynb';p.write_text(json.dumps(nb,ensure_ascii=False,indent=1))
for c in cells:
 if c['cell_type']=='code':compile(''.join(c['source']),'<cell>','exec')
print('Notebook compilation PASS',p)
(R/'helpers.py').write_text(helpers)
