def load_indices(path):
    archive = np.load(checked(path), allow_pickle=False)

    def pick(names):
        for name in names:
            if name in archive:
                return np.asarray(archive[name], dtype=np.int64).reshape(-1)
        raise KeyError(f'Índices ausentes: {names}; disponíveis={archive.files}')
    return (pick(['train', 'train_idx', 'idx_train']), pick(['validation', 'val', 'validation_idx', 'val_idx', 'idx_val']), pick(['test', 'test_idx', 'idx_test']))

def load_dataset(freeze_root, dataset, config):
    root = freeze_root / dataset / 'SCIENTIFIC_FREEZE'
    partition = root / 'official_client_partition_noniid_seed42.npz'
    preprocessing = root / 'preprocessing_train_only.npz'
    initial_path = root / 'shared_initial_state.npy'
    assert sha256_file(partition) == config['partition_sha256']
    assert sha256_file(preprocessing) == config['preprocessing_sha256']
    assert sha256_file(initial_path) == config['initial_state_sha256']
    client_archive = np.load(checked(partition), allow_pickle=False)
    client_indices = []
    for client_id in range(CLIENTS):
        possible = [f'client_{client_id}', f'client{client_id}', f'client_{client_id}_indices', f'client{client_id}_indices', str(client_id)]
        for key in possible:
            if key in client_archive:
                client_indices.append(np.asarray(client_archive[key], dtype=np.int64).reshape(-1))
                break
        else:
            raise KeyError(f'{dataset}: cliente {client_id} ausente')
    if dataset == 'PHYSIONET_CHALLENGE_2012':
        data_path = root / 'physionet_challenge_2012_features.csv'
        assert sha256_file(data_path) == config['data_sha256']
        frame = pd.read_csv(checked(data_path))
        features = [c for c in frame.columns if c not in {'RecordID', 'target'}]
        X = frame[features].apply(pd.to_numeric, errors='coerce').to_numpy(np.float64)
        y = pd.to_numeric(frame['target']).to_numpy(np.int64)
        train, validation, test = load_indices(root / 'official_split_seed42.npz')
    elif dataset == 'DAHL_RATS':
        data_path = root / 'dahl_derived_features.csv'
        assert sha256_file(data_path) == config['data_sha256']
        frame = pd.read_csv(checked(data_path))
        X = frame[DAHL_FEATURES].apply(pd.to_numeric, errors='coerce').to_numpy(np.float64)
        y = pd.to_numeric(frame['target']).to_numpy(np.int64)
        train, validation, test = load_indices(root / 'official_split_seed42.npz')
    else:
        data_path = root / 'chexchonet_embeddings.npz'
        assert sha256_file(data_path) == config['data_sha256']
        archive = np.load(checked(data_path), allow_pickle=False)
        X = np.asarray(archive['embeddings'], dtype=np.float64)
        y = np.asarray(archive['targets'], dtype=np.int64)
        raw = np.load(checked(root / 'official_split_original.npy'), allow_pickle=True)

        def normalize_split(value):
            if isinstance(value, (bytes, np.bytes_)):
                value = value.decode('utf-8')
            text = str(value).strip().lower()
            return {'0': 'train', '1': 'validation', '2': 'test', 'val': 'validation', 'valid': 'validation', 'dev': 'validation'}.get(text, text)
        labels = np.array([normalize_split(value) for value in raw])
        train = np.where(labels == 'train')[0]
        validation = np.where(labels == 'validation')[0]
        test = np.where(labels == 'test')[0]
    prep = np.load(checked(preprocessing), allow_pickle=True)
    median = np.asarray(prep['median'], dtype=np.float64)
    mean = np.asarray(prep['mean'], dtype=np.float64)
    std = np.asarray(prep['std'], dtype=np.float64)
    X = (np.where(np.isfinite(X), X, median) - mean) / std
    initial = np.asarray(np.load(checked(initial_path), allow_pickle=False), dtype=np.float64).reshape(-1)
    assert np.isfinite(X).all()
    assert np.isfinite(initial).all()
    assert len(initial) == X.shape[1] + 1
    assert len(train) == config['train_count']
    assert len(validation) == config['validation_count']
    assert len(test) == config['test_count']
    assert not (set(train) & set(validation) or set(train) & set(test) or set(validation) & set(test))
    assert set(np.concatenate(client_indices)) == set(train)
    return {'X': X, 'y': y, 'train': train, 'validation': validation, 'test': test, 'initial': initial}

def sigmoid(values):
    values = np.clip(values, -40, 40)
    return 1.0 / (1.0 + np.exp(-values))

def expected_calibration_error(y_true, probabilities, bins=10):
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = len(y_true)
    result = 0.0
    for index in range(bins):
        lower, upper = (edges[index], edges[index + 1])
        if index == bins - 1:
            mask = (probabilities >= lower) & (probabilities <= upper)
        else:
            mask = (probabilities >= lower) & (probabilities < upper)
        if not np.any(mask):
            continue
        confidence = float(np.mean(probabilities[mask]))
        observed = float(np.mean(y_true[mask]))
        result += float(np.sum(mask)) / total * abs(confidence - observed)
    return result

def evaluate_independently(state, X, y, indices):
    probabilities = sigmoid(X[indices] @ state[:-1] + state[-1])
    predictions = (probabilities >= THRESHOLD).astype(np.int64)
    truth = y[indices]
    tn, fp, fn, tp = confusion_matrix(truth, predictions, labels=[0, 1]).ravel()
    metrics = {'accuracy': float(accuracy_score(truth, predictions)), 'precision': float(precision_score(truth, predictions, zero_division=0)), 'recall': float(recall_score(truth, predictions, zero_division=0)), 'f1': float(f1_score(truth, predictions, zero_division=0)), 'auroc': float(roc_auc_score(truth, probabilities)) if len(np.unique(truth)) == 2 else None, 'log_loss': float(log_loss(truth, probabilities, labels=[0, 1])), 'brier_score': float(brier_score_loss(truth, probabilities)), 'ece_10_bins': float(expected_calibration_error(truth, probabilities, bins=10)), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}
    return (metrics, probabilities, predictions)

def metrics_match(recalculated, recorded, tolerance=FLOAT_TOL):
    fields = ['accuracy', 'precision', 'recall', 'f1', 'auroc']
    numeric_ok = all((recalculated[field] is None and recorded.get(field) is None or math.isclose(float(recalculated[field]), float(recorded[field]), rel_tol=0.0, abs_tol=tolerance) for field in fields))
    matrix_ok = all((int(recalculated[field]) == int(recorded[field]) for field in ['tn', 'fp', 'fn', 'tp']))
    return numeric_ok and matrix_ok