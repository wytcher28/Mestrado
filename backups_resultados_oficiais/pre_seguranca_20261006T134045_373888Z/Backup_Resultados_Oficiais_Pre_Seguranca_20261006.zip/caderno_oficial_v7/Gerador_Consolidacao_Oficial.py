from pathlib import Path
import json,zipfile,hashlib,shutil,math
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path('caderno_oficial_v7');D=R/'dados';G=R/'graficos';S=R/'fontes'
for d in [D,G,S]:d.mkdir(exist_ok=True)
latest=Path('upload/relatorios_demonstracoes (1).zip');previous=Path('upload/relatorios_demonstracoes.zip')
target=S/'extracao_oficial';target.mkdir(exist_ok=True)
with zipfile.ZipFile(latest) as z:
 for n in z.namelist():
  if n.startswith('S02_') and Path(n).name==n:(target/n).write_bytes(z.read(n))
shutil.copyfile('campanha_evidencias.json',S/'campanha_evidencias.json')
def f(n,old=False):return pd.read_csv((S/'extracao_oficial')/n)
def j(n,old=False):return json.loads(((S/'extracao_oficial')/n).read_text())
timing=f('S02_OVERHEAD_BY_ROUND.csv');comm=f('S02_COMMUNICATION_BY_ROUND.csv');cef=f('S02_CEF_BY_RUN.csv')
meta=json.loads((S/'campanha_evidencias.json').read_text())
SC=['BASELINE','CKKS','HYBRID'];SEEDS=[42,123,2026];names={'PHYSIONET_CHALLENGE_2012':'PhysioNet 2012','DAHL_RATS':'Dahl Rats','CHEXCHONET':'CheXchoNet'};DS=list(names);palette=['#607d8b','#247ba0','#d07a24']
finals=[];configs=[];gates=[]
for x in meta['arquivos_metadados']:
 q=x['metadados'];q=dict(q,source_path=x['arquivo'])
 if x['arquivo'].endswith('FINAL_RESULT.json'):finals.append(q)
 elif x['arquivo'].endswith('RUN_CONFIG.json'):configs.append(q)
 elif x['arquivo'].endswith('MASTER_GATE.json') or x['arquivo'].endswith('AUDIT_MASTER.json'):gates.append(q)
off=[q for q in finals if '/07_CORRECTED_OFFICIAL_CAMPAIGN/' in q['source_path']];gate_runs=[q for q in finals if q not in off];assert len(off)==27
F=pd.json_normalize(off);F.to_csv(D/'01_runs_oficiais_todos_campos.csv',index=False)

pd.json_normalize([x for x in configs if '/07_CORRECTED_OFFICIAL_CAMPAIGN/' in x['source_path']]).to_csv(D/'03_configuracoes_todos_campos.csv',index=False)
pd.json_normalize(gates).to_csv(D/'04_gates_estruturais_todos_campos.csv',index=False)
for n in (S/'extracao_oficial').glob('*.csv'):shutil.copyfile(n,D/n.name)
merged=timing.merge(comm,on=['seed','dataset','scenario','round'],validate='one_to_one');assert len(merged)==810;merged.to_csv(D/'05_810_rodadas_tempo_e_comunicacao.csv',index=False)
metric_cols=['accuracy','precision','recall','f1','auroc'];measure_cols=['total_wall_seconds','total_communication_bytes']+[c for c in F if c.startswith('measurement_summary.') and pd.api.types.is_numeric_dtype(F[c]) and not pd.api.types.is_bool_dtype(F[c])]
summary_cols=[f'{split}.{k}' for split in ['validation','test'] for k in metric_cols]+measure_cols
summ=F.groupby(['dataset','scenario'])[summary_cols].agg(['count','mean','std','min','max']);summ.to_csv(D/'06_estatisticas_entre_seeds.csv')
timecols=[c for c in timing if c.endswith('seconds') or c.endswith('sequential_clients') or c.endswith('residual')];timing.groupby(['dataset','scenario'])[timecols].agg(['count','mean','std','min','max']).to_csv(D/'07_estatisticas_rodadas_descritivas.csv')
# PDF helpers
for font,fn in [('DV','DejaVuSans.ttf'),('DV-Bold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(font,'/usr/share/fonts/truetype/dejavu/'+fn))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV',boldItalic='DV-Bold')
styles=getSampleStyleSheet()
for st in styles.byName.values():st.fontName='DV'
styles.add(ParagraphStyle(name='B',fontName='DV',fontSize=9.4,leading=13.5,spaceAfter=7))
styles.add(ParagraphStyle(name='T',fontName='DV',fontSize=7.0,leading=9))
styles.add(ParagraphStyle(name='H',parent=styles['T'],textColor=colors.white))
story=[];figure_inventory=[];table_inventory=[]
def p(s):story.append(Paragraph(s,styles['B']))
def h(s):story.append(Paragraph(s,styles['Heading1']));story.append(Spacer(1,5))
def sub(s):story.append(Paragraph(s,styles['Heading2']))
def page():story.append(PageBreak())
def fmt(v,d=4):
 if v is None or (isinstance(v,(float,np.floating)) and not np.isfinite(v)):return '—'
 if isinstance(v,(bool,np.bool_)):return str(bool(v))
 if isinstance(v,str):return v
 if abs(v)>0 and abs(v)<.0001:return f'{v:.3e}'
 return f'{v:.{d}f}'.replace('.',',')
def tab(headers,rows,widths=None,caption=None):
 if caption:sub(caption)
 cellrows=[[Paragraph(str(x),styles['H']) for x in headers]]+[[Paragraph(str(x),styles['T']) for x in row] for row in rows]
 t=Table(cellrows,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#163c54')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#edf3f7'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]));story.append(t);story.append(Spacer(1,8))
 table_inventory.append(caption or 'Tabela de valores disponíveis')
def chart(fig,name,caption,height=320):
 fig.savefig(G/(name+'.png'),dpi=170,bbox_inches='tight');fig.savefig(G/(name+'.svg'),bbox_inches='tight');plt.close(fig)
 from PIL import Image as PI
 im=PI.open(G/(name+'.png'));w,hh=im.size;maxw=510;maxh=height;scale=min(maxw/w,maxh/hh)
 story.append(Image(str(G/(name+'.png')),width=w*scale,height=hh*scale));p(caption);figure_inventory.append({'file':name,'caption':caption})
def meansd(series,d=4):return fmt(series.mean(),d)+' ± '+fmt(series.std(ddof=1),d)
# Official introduction
h('Resultados oficiais — campanha com três seeds');p('Geanderson Braga Lopes • FT/Unicamp • 06/10/2026')
p('Esta parte consolida exclusivamente os 27 runs oficiais, 810 rodadas e seeds 42, 123 e 2026. A seção histórica da Fase 22 conserva as curvas preditivas, deltas contínuos e CPU da seed 42. A ampliação não substitui essas medições.')
tab(['Critério','Tratamento final'],[['Comparação preditiva','Valores individuais por seed; médias e DP com n=3.'],['Custos','Wall, online e end-to-end separados. Setup externo Hybrid é composto.'],['Comunicação','Contadores por protocolo mantidos; CEF somente no uplink definido.'],['Histórico seed 42','Curvas, checkpoints, CPU e auditoria conservados.'],['Escopo de segurança','Isolamento lógico; ataques e ganho por segregação ainda pendentes.']],[145,365])
p('Os pilotos complementares são mencionados apenas como atividades exploratórias externas. Seus resultados de inversão, entropia, overhead ou comunicação não integram tabelas, gráficos ou estatísticas desta edição oficial.')
page();h('1. Protocolo e nomenclatura consolidados')
p('Regressão logística, SGD, 30 rodadas, cinco clientes sequenciais, três épocas locais, batch 64 e learning rate 0,1. Seeds 42/123/2026 alteram treinamento, mantendo splits, partições, pré-processamento e inicialização congelados. Teste final após rodada 30.')
tab(['Dataset','Atributos / parâmetros','Treino / validação / teste'],[['PhysioNet Challenge 2012','265 / 266','8.400 / 1.200 / 2.400'],['Dahl Rats','12 / 13','420 / 60 / 120'],['CheXchoNet','512 / 513','50.233 / 7.319 / 14.037']],[180,130,200])
p('PhysioNet 2012 não é MIMIC-III. CheXchoNet usa embeddings. Hybrid usa Rubato80S + RtF, não AES. CKKS: grau 8192, cadeia [60,40,40,60], escala 2^40. Escala de transporte Hybrid: 0,125.')
p('Médias ± DP usam três runs por dataset/cenário. Estatísticas de rodadas são descrições de séries dependentes, não 810 réplicas independentes. Curvas de qualidade, ganho temporal, checkpoints, deltas de calibração e CPU disponíveis para seed 42 estão preservados na seção Fase22; não são extrapolados às novas seeds.')
p('Não há predições individuais para gerar ROC/PR ou novas curvas de calibração. AUROC final é escalar. As curvas históricas foram mantidas do PDF original; não foram reconstruídas a partir de figuras nem recalculadas com fontes incompletas.')
# QUALITY all
for ds in DS:
 page();h('2. Qualidade final — '+names[ds]);part=F[F.dataset==ds].sort_values(['training_seed','scenario'])
 for split,label in [('validation','Validação'),('test','Teste')]:
  rows=[]
  for _,r in part.iterrows():rows.append([int(r.training_seed),r.scenario]+[fmt(r[f'{split}.{m}']) for m in metric_cols])
  tab(['Seed','Cenário','Accuracy','Precision','Recall','F1','AUROC'],rows,[40,70,80,80,80,80,80],label+' — todos os runs')
 p('Valores finais em escala 0–1; threshold 0,5. Accuracy deve ser lida junto com recall/F1 e desbalanceamento. Todas as métricas disponíveis são exibidas, inclusive valores zero.')
 for split,label in [('validation','Validação'),('test','Teste')]:
  page();h('Qualidade: '+names[ds]+' — '+label)
  fig,axes=plt.subplots(2,3,figsize=(10,6.2),layout='constrained');axes=axes.ravel()
  for ax,m in zip(axes,metric_cols):
   for k,sc in enumerate(SC):
    vv=part[part.scenario==sc][f'{split}.{m}'].to_numpy();ax.bar(k,np.mean(vv),color=palette[k],alpha=.55);ax.errorbar(k,np.mean(vv),yerr=np.std(vv,ddof=1),fmt='none',color='#222',capsize=3);ax.scatter(k+np.linspace(-.12,.12,len(vv)),vv,color='#202020',s=18,zorder=4)
   ax.set_xticks(range(3),SC,fontsize=8);ax.set_ylim(0,1.05);ax.set_title(m);ax.grid(axis='y',alpha=.2)
  axes[-1].axis('off');axes[-1].text(0,.7,'Barras: média de 3 seeds\nHastes: DP amostral\nPontos: runs individuais\nNão são ICs.',fontsize=11)
  chart(fig,f'qualidade_{ds}_{split}','Cinco métricas finais: média, DP e valores individuais. Pontos muito próximos podem se sobrepor.',430)
  rows=[[sc]+[meansd(part[part.scenario==sc][f'{split}.{m}']) for m in metric_cols] for sc in SC]
  tab(['Cenário','Accuracy','Precision','Recall','F1','AUROC'],rows,[70,88,88,88,88,88],label+' — média ± DP')
 # confusion combined both splits tables plus figs
 for split,label in [('validation','Validação'),('test','Teste')]:
  page();h('Matrizes de confusão — '+names[ds]+' — '+label)
  fig,axes=plt.subplots(3,3,figsize=(9,7.7),layout='constrained')
  for i,seed in enumerate(SEEDS):
   for k,sc in enumerate(SC):
    r=part[(part.training_seed==seed)&(part.scenario==sc)].iloc[0];mat=np.array([[r[f'{split}.tn'],r[f'{split}.fp']],[r[f'{split}.fn'],r[f'{split}.tp']]],int);ax=axes[i,k];ax.imshow(mat,cmap='Blues')
    for rr in range(2):
     for cc in range(2):ax.text(cc,rr,str(mat[rr,cc]),ha='center',va='center',color='white' if mat[rr,cc]>mat.max()/2 else 'black',fontsize=10)
    ax.set_title(f'{sc} • seed {seed}',fontsize=9);ax.set_xticks([0,1],['Pred. 0','Pred. 1'],fontsize=7);ax.set_yticks([0,1],['Real 0','Real 1'],fontsize=7)
  chart(fig,f'confusao_{ds}_{split}','Contagens absolutas finais; cada matriz usa sua própria escala de cor. Células: TN, FP / FN, TP.',465)
  rows=[[int(r.training_seed),r.scenario]+[int(r[f'{split}.{m}']) for m in ['tn','fp','fn','tp']] for _,r in part.iterrows()]
  tab(['Seed','Cenário','TN','FP','FN','TP'],rows,[50,100,90,90,90,90])
# HISTORICAL run costs all numeric
for ds in DS:
 page();h('3. Custos por run — '+names[ds]);part=F[F.dataset==ds].sort_values(['training_seed','scenario'])
 cols=[('total_wall_seconds','Wall (s)'),('measurement_summary.total_online_seconds','Online (s)'),('measurement_summary.total_crypto_setup_seconds','Setup/res. (s)'),('measurement_summary.total_end_to_end_seconds','E2E (s)')]
 tab(['Seed','Cenário']+[l for c,l in cols],[[int(r.training_seed),r.scenario]+[fmt(r.get(c),2) for c,l in cols] for _,r in part.iterrows()],[45,80,96,96,96,97],'Tempos históricos disponíveis')
 cols=[('measurement_summary.peak_end_to_end_rss_bytes','Pico RSS (GiB)'),('measurement_summary.peak_separate_ckks_setup_rss_bytes','Pico setup (GiB)'),('measurement_summary.setup_communication_bytes','Setup (MiB)'),('measurement_summary.online_communication_bytes','Online (MiB)'),('total_communication_bytes','Total contador (MiB)')]
 tab(['Seed','Cenário']+[l for c,l in cols],[[int(r.training_seed),r.scenario]+[fmt(r.get(c)/(2**30 if 'rss' in c else 2**20),3) if pd.notna(r.get(c)) else '—' for c,l in cols] for _,r in part.iterrows()],[40,70,80,80,80,80,80],'Memória e contadores históricos')
 p('GiB/MiB usam divisores 2^30/2^20. Setup Hybrid não foi serializado. Pico zero pode significar campo não aplicável: não é demonstração de ausência de memória. “Total contador” preserva o número reportado; não é custo completo harmonizado de rede. O resíduo externo Hybrid inclui outras tarefas.')
 # 6panel costs
 page();h('Custos: visão gráfica — '+names[ds]);fig,axes=plt.subplots(2,3,figsize=(10,6.5),layout='constrained')
 specs=[('measurement_summary.total_online_seconds','Online (s)',1),('measurement_summary.total_end_to_end_seconds','E2E (s)',1),('measurement_summary.total_crypto_setup_seconds','Setup/resíduo (s)',1),('measurement_summary.peak_end_to_end_rss_bytes','Pico RSS (GiB)',2**30),('measurement_summary.online_communication_bytes','Contador online (MiB)',2**20),('total_communication_bytes','Contador total (MiB)',2**20)]
 for ax,(col,label,div) in zip(axes.ravel(),specs):
  for k,sc in enumerate(SC):
   v=part[part.scenario==sc][col].dropna().to_numpy()/div;ax.bar(k,np.mean(v),color=palette[k],alpha=.65);ax.scatter(k+np.linspace(-.1,.1,len(v)),v,color='#222',s=16,zorder=3)
  ax.set_xticks(range(3),SC,fontsize=7);ax.set_title(label,fontsize=10);ax.set_yscale('symlog',linthresh=.001);ax.grid(axis='y',alpha=.2)
 chart(fig,'custos_'+ds,'Médias por cenário e pontos por seed. Eixo symlog para preservar zeros e ordens de grandeza. Contadores de comunicação não cobrem fluxos iguais entre cenários.',440)
# TIMING curves for all available fields grouped panels9 every metric
labels={'training_seconds_sum_sequential_clients':'Treino sequencial','encryption_with_serialization_seconds':'Encryption + serialização','aggregation_seconds':'Agregação','decryption_with_deserialization_seconds':'Decrypt + desserialização','hybrid_bridge_composite_seconds':'Bridge Hybrid composto','reported_setup_or_outer_residual_seconds':'Setup/resíduo externo','other_seconds_arithmetic_residual':'Outras tarefas: resíduo aritmético','end_to_end_seconds':'Tempo end-to-end'}
for col,label in labels.items():
 page();h('4. Séries por rodada — '+label)
 fig,axes=plt.subplots(3,3,figsize=(10,7.2),layout='constrained')
 for i,ds in enumerate(DS):
  for k,sc in enumerate(SC):
   ax=axes[i,k]
   for seed in SEEDS:
    q=timing[(timing.dataset==ds)&(timing.scenario==sc)&(timing.seed==seed)].sort_values('round');ax.plot(q['round'],q[col],label=str(seed),linewidth=1)
   ax.set_title(names[ds]+' / '+sc,fontsize=8);ax.set_xlabel('Rodada',fontsize=7);ax.set_ylabel('s',fontsize=7);ax.tick_params(labelsize=7);ax.grid(alpha=.2)
   if timing[(timing.dataset==ds)&(timing.scenario==sc)][col].notna().sum()==0:ax.text(.5,.5,'Não medido',transform=ax.transAxes,ha='center')
 axes[0,0].legend(fontsize=7);chart(fig,'rodadas_'+col,'30 rodadas por run; curvas por seed. Não medido permanece sem curva. Campos residuais não são estimativas de criptografia nem de rede.',465)
 rows=[]
 for ds in DS:
  for sc in SC:
   v=timing[(timing.dataset==ds)&(timing.scenario==sc)][col].dropna();rows.append([names[ds],sc,len(v),fmt(v.mean(),5),fmt(v.std(),5),fmt(v.min(),5),fmt(v.max(),5)])
 tab(['Dataset','Cenário','n rod.','Média','DP','Mín.','Máx.'],rows,[105,60,40,76,76,76,77])
# cef all values
page();h('5. Comunicação: todos os contadores e fatores')
p('CEF harmonizado = uplink dos clientes protegido / uplink dos clientes Baseline. Razão legada = contadores online reportados / contador online Baseline; preservada para diagnóstico, mas NÃO é CEF completo comparável. Setup/download/framing são excluídos do CEF uplink.')
for ds in DS:
 q=cef[cef.dataset==ds].sort_values(['seed','scenario']);tab(['Seed','Cenário','Online bytes','CKKS uplink bytes','Baseline uplink bytes','Razão legada','CEF uplink'],[[int(r.seed),r.scenario,int(r.recorded_online_bytes),fmt(r.ckks_client_upload_bytes,0),fmt(r.baseline_client_upload_bytes,0),fmt(r.recorded_counter_ratio_NOT_HARMONIZED,2),fmt(r.client_uplink_cef,2)] for _,r in q.iterrows()],[35,55,85,90,90,75,80],names[ds])
page();h('Comunicação por rodada: evolução dos contadores')
fig,axes=plt.subplots(3,3,figsize=(10,7.1),layout='constrained')
for i,ds in enumerate(DS):
 for k,sc in enumerate(SC):
  ax=axes[i,k]
  for seed in SEEDS:
   q=comm[(comm.dataset==ds)&(comm.scenario==sc)&(comm.seed==seed)].sort_values('round');ax.plot(q['round'],q.recorded_online_bytes/2**20,label=str(seed))
  ax.set_title(names[ds]+' / '+sc,fontsize=8);ax.set_xlabel('Rodada',fontsize=7);ax.set_ylabel('MiB contador online',fontsize=7);ax.tick_params(labelsize=7);ax.grid(alpha=.2)
axes[0,0].legend(fontsize=7);chart(fig,'comunicacao_rodadas','Contadores reportados por protocolo. Fluxos não harmonizados; linhas coincidentes podem ocultar outras seeds.',475)
page();h('CEF CKKS histórico: comparação no mesmo fluxo');fig,ax=plt.subplots(figsize=(8,4))
for i,ds in enumerate(DS):
 v=cef[(cef.dataset==ds)&(cef.scenario=='CKKS')].client_uplink_cef.to_numpy();ax.bar(i,np.mean(v),color=palette[i],alpha=.7);ax.scatter(i+np.linspace(-.08,.08,3),v,color='#222');ax.text(i,np.mean(v)*1.2,f'{np.mean(v):.2f}×',ha='center')
ax.set_xticks(range(3),[names[d] for d in DS]);ax.set_yscale('log');ax.set_ylim(20,8000);ax.set_ylabel('CEF uplink (log)');chart(fig,'cef_historico','Média de três seeds e pontos individuais. Hybrid histórico não possui uplink separado medido.',320)
page();h('6. Fechamento da consistência oficial')
p('As 45 métricas de teste seed 42 impressas na Tabela 5.5 histórica coincidem com os registros atuais até a precisão de nove casas. Todos os 27 runs são aprovados. A soma dos tempos end-to-end das 810 rodadas coincide com os resumos finais; diferença máxima de aproximadamente 1,8×10^-15s.')
p('Não foram observados resíduos negativos no breakdown histórico. Zeros de placeholder da agregação Baseline foram tratados como não medidos. Transciphering histórico não foi separado e permanece ausente, sem preenchimento por valores de pilotos.')
p('Setup CKKS representa preparação registrada; setup Hybrid histórico representa o resíduo externo composto de preparação, compilação/processo e I/O. A interpretação do campo foi corrigida; seus valores originais permanecem intactos.')
p('Contadores online Baseline, CKKS e Hybrid abrangem fluxos distintos. Os volumes históricos são mantidos como medições por protocolo. A razão legada é diagnóstico e não CEF completo. CEF uplink CKKS compara o mesmo envio dos clientes; não inclui download global, framing ou distribuição de chaves.')
p('O protótipo Hybrid mantém custo maior nesta implementação. Isso é resultado, não falha a corrigir por reexecução. Não houve novo treinamento nem alteração dos resultados para confirmar uma hipótese.')
p('Campanha de segurança ainda pendente: agregação antes de decrypt e ausência de decrypt individual são propriedades observadas; não comprovam segurança sob comprometimento nem isolamento independente de servidores.')
p('Fontes desta parte: FINAL_RESULT/RUN_CONFIG oficiais da coleta histórica e S02 do extrator. Gates exploratórios e números dos pilotos foram excluídos da consolidação.')
page();h('7. Rastreabilidade e arquivos oficiais')
p('01_runs_oficiais_todos_campos.csv: 27 runs.<br/>03_configuracoes_todos_campos.csv: configurações oficiais.<br/>04_gates_estruturais_todos_campos.csv: auditorias e master gates.<br/>05_810_rodadas_tempo_e_comunicacao.csv: 810 registros, junção 1:1.<br/>06_estatisticas_entre_seeds.csv: count/mean/std/min/max por run.<br/>07_estatisticas_rodadas_descritivas.csv: séries temporais.<br/>CSVs S02: extração dos registros oficiais.<br/>Anexo_810_Rodadas_Oficiais.pdf: valores completos por rodada.')
p('Versões anteriores continuam preservadas. Pilotos foram retirados desta apresentação por decisão do autor; permanecem em seus arquivos e relatórios originais, sem descarte do acervo.')
manifest={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [latest,Path('campanha_evidencias.json')]};(D/'FONTES_SHA256.json').write_text(json.dumps(manifest,indent=2))
# build PDF
PDF=R/'Parte_Consolidacao_Oficial_3_Seeds.pdf'
def footer(c,d):
 c.setFont('DV',7);c.setFillColor(colors.HexColor('#506476'));c.drawString(40,24,'Inventário completo FL • 06/10/2026');c.drawRightString(555,24,str(d.page))
SimpleDocTemplate(str(PDF),pagesize=(595.28,841.89),leftMargin=40,rightMargin=40,topMargin=38,bottomMargin=42,title='Caderno completo de resultados FL',author='Geanderson Lopes').build(story,onFirstPage=footer,onLaterPages=footer)
# Full round tables: 2 pages per run; all numeric fields + communication. No truncation.
story=[]
for ds in DS:
 for sc in SC:
  for seed in SEEDS:
   q=merged[(merged.dataset==ds)&(merged.scenario==sc)&(merged.seed==seed)].sort_values('round');assert len(q)==30
   h('Rodadas: '+names[ds]+' / '+sc+' / seed '+str(seed));p('Página A: segundos. Valores ausentes indicados por —; não são zeros.')
   cols=['training_seconds_sum_sequential_clients','encryption_with_serialization_seconds','aggregation_seconds','decryption_with_deserialization_seconds','transciphering_seconds','hybrid_bridge_composite_seconds']
   tab(['Rod.','Treino','Encrypt','Agregação','Decrypt','Transcipher','Bridge'],[[int(r['round'])]+[fmt(r[c],6) for c in cols] for _,r in q.iterrows()],[35,80,80,80,80,80,75]);page()
   h('Rodadas: '+names[ds]+' / '+sc+' / seed '+str(seed));p('Página B: tempos restantes e comunicação. Setup Hybrid é resíduo externo; online bytes tem escopo próprio do protocolo.')
   cols=['reported_setup_or_outer_residual_seconds','other_seconds_arithmetic_residual','end_to_end_seconds','recorded_online_bytes','ckks_client_upload_bytes','baseline_client_upload_bytes']
   tab(['Rod.','Setup/res. s','Outras s','E2E s','Online bytes','CKKS uplink','Base uplink'],[[int(r['round'])]+[fmt(r[c],5 if c.endswith('seconds') or c.endswith('residual') else 0) for c in cols] for _,r in q.iterrows()],[35,80,80,80,80,80,75]);p('Escopo de comunicação: '+str(q.measurement_scope.iloc[0]))
   if not (ds==DS[-1] and sc==SC[-1] and seed==SEEDS[-1]):page()
SimpleDocTemplate(str(R/'Anexo_810_Rodadas_Oficiais.pdf'),pagesize=(595.28,841.89),leftMargin=40,rightMargin=40,topMargin=38,bottomMargin=42,title='Anexo: 810 rodadas FL',author='Geanderson Lopes').build(story,onFirstPage=footer,onLaterPages=footer)
(D/'INDICE_FIGURAS.json').write_text(json.dumps(figure_inventory,ensure_ascii=False,indent=2));(D/'INDICE_TABELAS.json').write_text(json.dumps(table_inventory,ensure_ascii=False,indent=2))
shutil.copyfile(__file__,R/'Gerador_Consolidacao_Oficial.py')
print('PDF',PDF,'figures',len(figure_inventory),'tables',len(table_inventory))
