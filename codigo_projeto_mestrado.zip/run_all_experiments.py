import os
import sys
import pandas as pd
import matplotlib.pyplot as plt

sys.path.append("/content/Mestrado-main")

from run_colab_experiment import run_experiment


def generate_figures(base_dir="results", out_dir="figuras_saida"):
    os.makedirs(out_dir, exist_ok=True)

    scenarios = ["baseline", "ckks", "hybrid"]
    dfs = {}

    for s in scenarios:
        path = os.path.join(base_dir, s, "rounds.csv")
        dfs[s] = pd.read_csv(path)

    # Tempo por rodada
    plt.figure(figsize=(8, 5))
    for s, df in dfs.items():
        plt.plot(df["round"], df["latency_round_ms"], marker="o", label=s)
    plt.xlabel("Rodada")
    plt.ylabel("Latência por rodada (ms)")
    plt.title("Tempo médio de execução por rodada federada")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "tempo_por_rodada.png"))
    plt.close()

    # Accuracy
    plt.figure(figsize=(8, 5))
    for s, df in dfs.items():
        plt.plot(df["round"], df["val_accuracy"], marker="o", label=s)
    plt.xlabel("Rodada")
    plt.ylabel("Acurácia")
    plt.title("Acurácia do modelo ao longo das rodadas")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "logreg_acc.png"))
    plt.close()

    # F1
    plt.figure(figsize=(8, 5))
    for s, df in dfs.items():
        plt.plot(df["round"], df["val_f1"], marker="o", label=s)
    plt.xlabel("Rodada")
    plt.ylabel("F1-score")
    plt.title("F1-score do modelo ao longo das rodadas")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "logreg_f1.png"))
    plt.close()

    # AUC
    plt.figure(figsize=(8, 5))
    for s, df in dfs.items():
        plt.plot(df["round"], df["val_auc"], marker="o", label=s)
    plt.xlabel("Rodada")
    plt.ylabel("AUC")
    plt.title("AUC do modelo ao longo das rodadas")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "logreg_auc.png"))
    plt.close()

    # Tabela-resumo
    summary_rows = []
    for s, df in dfs.items():
        summary_rows.append({
            "scenario": s,
            "rounds": len(df),
            "latency_mean_ms": df["latency_round_ms"].mean(),
            "accuracy_last": df["val_accuracy"].iloc[-1],
            "f1_last": df["val_f1"].iloc[-1],
            "auc_last": df["val_auc"].iloc[-1],
        })

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(os.path.join(out_dir, "summary_table.csv"), index=False)

    print(summary)


def main():
    for scenario in ["baseline", "ckks", "hybrid"]:
        run_experiment(scenario)

    generate_figures()


if __name__ == "__main__":
    main()
