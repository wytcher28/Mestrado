import os
import tenseal as ts
import numpy as np


class HEContext:

    def __init__(
        self,
        poly_modulus_degree=8192,
        coeff_mod_bit_sizes=None,
        global_scale=2**40,
    ):

        if coeff_mod_bit_sizes is None:
            coeff_mod_bit_sizes = [60, 40, 40, 60]

        self.ctx = ts.context(
            ts.SCHEME_TYPE.CKKS,
            poly_modulus_degree=poly_modulus_degree,
            coeff_mod_bit_sizes=coeff_mod_bit_sizes,
        )

        self.ctx.generate_galois_keys()
        self.ctx.global_scale = global_scale


    def encrypt_vector(self, vec):
        return ts.ckks_vector(self.ctx, list(vec))


    def decrypt_vector(self, enc_vec):
        return np.array(enc_vec.decrypt(), dtype=np.float64)


    def serialize_ciphertext(self, enc_vec):
        return enc_vec.serialize()


    def deserialize_ciphertext(self, blob):
        return ts.ckks_vector_from(self.ctx, blob)


    @staticmethod
    def random_bytes(n=32):
        return os.urandom(n)
