import time
import numpy as np

from sklearn.neural_network import MLPClassifier

from flhe.models.mlp import init_model, get_shapes, get_flat_weights, set_flat_weights
from flhe.fl.utils import split_clients
from flhe.crypto.he_ckks import HEContext
from flhe.metrics.evaluation import evaluate_binary, safe_predict_proba


def run_federated_training(
    scenario,
    X_train,
    y_train,
    X_val,
    y_val,
    rounds=5,
    num_clients=5,
    seed=42,
    logger=None
):
    if scenario not in ("baseline", "ckks", "hybrid"):
        raise ValueError(f"invalid scenario: {scenario}")

    model = MLPClassifier(
        hidden_layer_sizes=(32,),
        max_iter=1,
        warm_start=True,
        random_state=seed
    )
    model = init_model(model, X_train[:200], y_train[:200])

    shapes = get_shapes(model)
    clients = split_clients(X_train, y_train, num_clients=num_clients, seed=seed)

    he = None
    if scenario in ("ckks", "hybrid"):
        he = HEContext()

    for r in range(1, rounds + 1):
        t0 = time.time()
        flat_global = get_flat_weights(model)
        updates = []

        for (Xc, yc) in clients:
            local = MLPClassifier(
                hidden_layer_sizes=(32,),
                max_iter=1,
                warm_start=True,
                random_state=seed
            )
            local = init_model(local, X_train[:200], y_train[:200])
            set_flat_weights(local, flat_global, shapes)

            local.partial_fit(Xc, yc)

            flat_local = get_flat_weights(local)
            update = flat_local - flat_global

            if scenario == "baseline":
                updates.append(update.astype(np.float64))
            else:
                ct = he.encrypt_vector(update.astype(np.float64))
                updates.append(ct)

        if scenario == "baseline":
            agg = np.mean(np.stack(updates), axis=0)
        else:
            agg_ct = None
            for ct in updates:
                if agg_ct is None:
                    agg_ct = ct
                else:
                    agg_ct += ct
            agg_ct *= (1.0 / len(updates))
            agg = he.decrypt_vector(agg_ct)

        new_flat = flat_global + agg
        set_flat_weights(model, new_flat, shapes)

        if len(X_val):
            y_pred = model.predict(X_val)
            y_proba = safe_predict_proba(model, X_val)
            m = evaluate_binary(y_val, y_pred, y_proba)
            acc = m["accuracy"]
            f1 = m["f1"]
            auc = m["auc"]
        else:
            acc = None
            f1 = None
            auc = None

        latency = (time.time() - t0) * 1000.0

        if logger:
            logger.log_round(
                round=r,
                val_accuracy=acc,
                val_f1=f1,
                val_auc=auc,
                latency_round_ms=latency
            )

    return model
