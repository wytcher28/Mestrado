from pathlib import Path
import json,zipfile,hashlib,shutil,math
import pandas as pd,numpy as np,fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path('caderno_oficial_v8');D=R/'dados_S08';G=R/'graficos_S08';S=R/'fontes_S08'
for d in [D,G,S]:d.mkdir(exist_ok=True)
source=Path('upload/S08_Cobertura_Tres_Seeds.zip')
with zipfile.ZipFile(source) as z:
 for n in z.namelist():
  assert Path(n).name==n;(S/n).write_bytes(z.read(n))
def f(n):return pd.read_csv(S/n)
r=f('S08_ALL_ROUND_FIELDS_810.csv');cl=f('S08_CLIENT_INSTRUMENTATION_4050.csv');cpu=f('S08_RUN_CPU_COSTS_27.csv');delta=f('S08_CONTINUOUS_DELTAS_27.csv');rec=f('S08_RECALCULATED_FINAL_METRICS_54.csv');cp=f('S08_CHECKPOINT_DELTAS_837.csv');gain=f('S08_TEMPORAL_GAINS_AND_DELTAS_810.csv');var=f('S08_VARIATION_COUNTS_27.csv');gate=json.loads((S/'S08_FINAL_GATE.json').read_text());assert gate['status']=='COVERAGE_APPROVED' and not gate['failed_checks']
DS=['PHYSIONET_CHALLENGE_2012','DAHL_RATS','CHEXCHONET'];SC=['BASELINE','CKKS','HYBRID'];SEEDS=[42,123,2026];names=dict(zip(DS,['PhysioNet 2012','Dahl Rats','CheXchoNet']));palette=['#607d8b','#247ba0','#d07a24']
for df,expected in [(r,270),(cl,1350),(rec,18),(delta,9),(cp,279)]:assert df.groupby('seed').size().to_dict()=={s:expected for s in SEEDS}
# Preserve final official values and verify recorded curves against frozen FINAL_RESULT summaries.
oldF=pd.read_csv('caderno_completo/dados/01_runs_oficiais_todos_campos.csv')
for _,row in oldF.iterrows():
 a=rec[(rec.seed==row.training_seed)&(rec.dataset==row.dataset)&(rec.scenario==row.scenario)]
 for split in ['validation','test']:
  b=a[a.split==split].iloc[0]
  for k in ['accuracy','precision','recall','f1','auroc']:assert abs(b[k]-row[split+'.'+k])<1e-12
 for split in ['validation']:
  last=r[(r.seed==row.training_seed)&(r.dataset==row.dataset)&(r.scenario==row.scenario)&(r['round']==30)].iloc[0]
  for k in ['accuracy','precision','recall','f1','auroc']:assert abs(last['validation.'+k]-row[split+'.'+k])<1e-12
# reuse presentation helpers only, not code/data extraction or training
helpers=Path('caderno_oficial_v7/build_core.py').read_text();helpers=helpers[helpers.index('# PDF helpers'):helpers.index('# Official introduction')]
exec(helpers)
h('Complemento oficial S08 — cobertura equivalente');p('Geanderson Braga Lopes • 06/10/2026 • Seeds 42, 123 e 2026')
p('Este complemento contém apenas processamento de registros e modelos finais congelados da campanha oficial. Não houve treinamento, seleção de hiperparâmetros ou execução criptográfica nova. Os pilotos não integram esta edição.')
tab(['Cobertura por seed','Quantidade'],[['Runs oficiais',9],['Rodadas registradas',270],['Clientes instrumentados',1350],['Avaliações finais: validação e teste',18],['Comparações contínuas finais',9],['Checkpoints: 31 por run',279]],[360,150])
p('S08: COVERAGE_APPROVED; 3.487 checks registrados, zero falhas. Foram avaliados 8.100 registros de presença de grupos de campos. Validação e teste finais foram recalculados com tolerância 1e−12 para métricas preditivas e matrizes de confusão exatas. Isso não é uma nova auditoria completa de execução/replay nem uma avaliação de segurança.')
p('Na seed42, as métricas finais e os resultados contínuos conferem com o histórico na precisão apresentada. Valores anteriores são conservados; as novas linhas tornam a apresentação simétrica entre seeds. Pequenos deltas são notados em escala científica, sem inventar offsets para zeros.')
p('ECE:10 bins uniformes em [0,1], última faixa inclui1; sigmoid limitada a [−40,40]; threshold0,5. Auditoria do teste final sem tuning. Python3.13.15; NumPy2.1.3; pandas2.2.3; scikit-learn1.6.1.')
# generic symmetric grids: rows datasets, columns seeds, colors scenarios

def grids(frame,col,title,file,scenarios=SC,log=False,client=False):
 page();h(title);fig,axes=plt.subplots(3,3,figsize=(10,7.2),layout='constrained')
 for i,ds in enumerate(DS):
  for k,seed in enumerate(SEEDS):
   ax=axes[i,k]
   if client:
    # Same local training in each protection scenario: show baseline observations only, verify counterparts below.
    for cid in range(5):
     q=frame[(frame.seed==seed)&(frame.dataset==ds)&(frame.scenario=='BASELINE')&(frame.client==cid)].sort_values('round');ax.plot(q['round'],q[col],label='Cliente '+str(cid),linewidth=1)
   else:
    for j,sc in enumerate(scenarios):
     q=frame[(frame.seed==seed)&(frame.dataset==ds)&(frame.scenario==sc)].sort_values('round');ax.plot(q['round'],q[col],color=palette[SC.index(sc)],label=sc,linewidth=1)
   ax.set_title(names[ds]+f' / seed{seed}',fontsize=8);ax.set_xlabel('Rodada',fontsize=7);ax.tick_params(labelsize=7);ax.grid(alpha=.2)
   if log:ax.set_yscale('symlog',linthresh=1e-12)
 axes[0,0].legend(fontsize=6)
 chart(fig,file,'Mesma medição para todas as seeds. Curvas coincidentes podem se sobrepor. '+('Escala symlog preserva zeros sem deslocamento.' if log else 'Escalas locais: observe os valores dos eixos.'),470)
for metric in ['accuracy','precision','recall','f1','auroc']:
 grids(r,'validation.'+metric,'Validação por rodada — '+metric,'validacao_'+metric)
 grids(gain,'validation_'+metric+'_gain_vs_round1','Ganho temporal em relação à rodada1 — '+metric,'ganho_'+metric)
# exact per-round differences as received
for col,title in [('validation_probability_max_abs_difference_from_clear_round','Maior diferença de probabilidade vs agregado em claro'),('validation_prediction_disagreement_from_clear_round','Discordância classificatória vs agregado em claro')]:grids(r,col,title,col,scenarios=['CKKS','HYBRID'],log='probability' in col)
for col in ['numeric_error.max_abs_error','numeric_error.mean_abs_error','numeric_error.rmse']:
 grids(r,col,'Fidelidade da agregação por rodada — '+col.replace('numeric_error.',''),col.replace('.','_'),scenarios=['CKKS','HYBRID'],log=True)
for col in ['state_l2_difference','state_max_abs_difference']:grids(cp,col,'Checkpoint vs Baseline da mesma seed — '+col,'checkpoint_'+col,scenarios=['CKKS','HYBRID'],log=True)
# final comparisons all fields
for ds in DS:
 page();h('Deltas contínuos finais — '+names[ds]);q=delta[delta.dataset==ds].sort_values(['seed','scenario'])
 groups=[(['state_l2_difference','state_max_abs_difference','probability_max_abs_difference','probability_mean_abs_difference','probability_l2_difference'],['L2 estado','Máx. estado','Máx. prob.','Média prob.','L2 prob.']),(['test_log_loss_delta','test_brier_score_delta','test_ece_10_bins_delta','test_auroc_delta','rank_correlation'],['Δlog-loss','ΔBrier','ΔECE','ΔAUROC','Corr. ranks'])]
 for cols,heads in groups:tab(['Seed','Cenário']+heads,[[int(x.seed),x.scenario]+[fmt(x[c],8) for c in cols] for _,x in q.iterrows()],[35,65,82,82,82,82,82])
 tab(['Seed','Cenário','Discordância n','Taxa','ΔAccuracy','ΔPrecision','ΔRecall','ΔF1'],[[int(x.seed),x.scenario,int(x.prediction_disagreement_count),fmt(x.prediction_disagreement_rate,8)]+[fmt(x['test_'+c+'_delta'],8) for c in ['accuracy','precision','recall','f1']] for _,x in q.iterrows()],[35,65,65,65,70,70,70,70])
 p('Todas as diferenças são relativas ao Baseline do mesmo dataset/seed no teste final. Distância entre estados não é erro de reconstrução de amostras. Deltas de loss/calibração residuais não estabelecem superioridade de um cenário.')
page();h('Deltas contínuos finais — gráficos por seed');fig,axes=plt.subplots(2,3,figsize=(10,6.5),layout='constrained');metrics=['state_l2_difference','probability_max_abs_difference','test_log_loss_delta','test_brier_score_delta','test_ece_10_bins_delta','test_auroc_delta'];xx=np.arange(9)
for ax,col in zip(axes.ravel(),metrics):
 for sc in ['CKKS','HYBRID']:
  vals=[delta[(delta.dataset==ds)&(delta.seed==seed)&(delta.scenario==sc)].iloc[0][col] for ds in DS for seed in SEEDS];ax.plot(xx,vals,marker='o',label=sc,color=palette[SC.index(sc)])
 ax.set_xticks(xx,[names[ds]+'\n'+str(seed) for ds in DS for seed in SEEDS],fontsize=5,rotation=65);ax.set_yscale('symlog',linthresh=1e-12);ax.set_title(col,fontsize=8);ax.grid(alpha=.2)
axes[0,0].legend(fontsize=7);chart(fig,'deltas_continuos_finais','Cada ponto mantém dataset/seed; escala symlog mostra sinais e zeros. Deltas de AUROC/loss não têm a mesma unidade das distâncias de estado.',455)
# recalculated finals all numerical fields added
for ds in DS:
 page();h('Métricas finais complementares — '+names[ds]);q=rec[rec.dataset==ds].sort_values(['seed','scenario'])
 for split in ['validation','test']:
  a=q[q.split==split];tab(['Seed','Cenário','Log-loss','Brier','ECE10','Confere registro'],[[int(x.seed),x.scenario,fmt(x.log_loss,9),fmt(x.brier_score,9),fmt(x.ece_10_bins,9),str(bool(x.recorded_metrics_match))] for _,x in a.iterrows()],[40,80,100,100,100,90],split)
 p('As cinco métricas preditivas e contagens de confusão já constam da ParteB oficial; S08 as recalculou e confirmou. Aqui são acrescentados os valores absolutos de log-loss, Brier e ECE, com igual cobertura nas seeds.')
# Variation counts: same columns perseed
for ds in DS:
 page();h('Variações nas30 rodadas — '+names[ds]);q=var[var.dataset==ds].sort_values(['seed','scenario'])
 cols=['accuracy_different_rounds','precision_different_rounds','recall_different_rounds','f1_different_rounds','auroc_different_rounds'];tab(['Seed','Cenário','Acc.','Prec.','Recall','F1','AUROC','Máx.Δp claro'],[[int(x.seed),x.scenario]+[str(int(x[c]))+'/30' for c in cols]+[fmt(x.max_probability_difference_from_clear_round,8)] for _,x in q.iterrows()],[35,65,60,60,60,60,60,110])
 p('Contagens de desigualdade estrita entre valores registrados: não medem significância estatística. Probabilidade registrada é relativa ao agregado em claro dentro da mesma rodada, distinta da comparação entre modelos finais acumulados.')
# CPU same fields allseeds
for ds in DS:
 page();h('CPU acumulada — '+names[ds]);q=cpu[cpu.dataset==ds].sort_values(['seed','scenario']);rows=[]
 for _,x in q.iterrows():
  base=q[(q.seed==x.seed)&(q.scenario=='BASELINE')].iloc[0].total_cpu_seconds_sum;rows.append([int(x.seed),x.scenario,fmt(x.python_cpu_seconds_sum,6),fmt(x.child_cpu_seconds_sum,6),fmt(x.total_cpu_seconds_sum,6),fmt(x.total_cpu_seconds_sum/base,3)])
 tab(['Seed','Cenário','Python(s)','Subprocessos(s)','Total(s)','Fator vs Base'],rows,[40,70,100,100,100,100])
 fig,axes=plt.subplots(1,2,figsize=(9,3.5),layout='constrained')
 for k,sc in enumerate(SC):
  vv=q[q.scenario==sc].set_index('seed').loc[SEEDS];x=np.arange(3)+(k-1)*.23;axes[0].bar(x,vv.total_cpu_seconds_sum,.23,label=sc,color=palette[k]);base=q[q.scenario=='BASELINE'].set_index('seed').loc[SEEDS].total_cpu_seconds_sum;axes[1].bar(x,vv.total_cpu_seconds_sum/base,.23,label=sc,color=palette[k])
 for ax in axes:ax.set_xticks(range(3),[str(s) for s in SEEDS]);ax.set_yscale('log');ax.grid(axis='y',alpha=.2)
 axes[0].set_title('CPU total(s)');axes[1].set_title('Amplificação vs Baseline');axes[0].legend(fontsize=7);chart(fig,'cpu_'+ds,'CPU acumulada Python + subprocessos, registrada por processo; pode exceder tempo de parede por paralelismo interno. Não confundir com wall time.',265)
# local instrumentation also measured, not discarded
for col,title in [('train_wall_seconds','Tempo local de treinamento dos clientes'),('train_cpu_seconds','CPU local de treinamento dos clientes'),('delta_l2_norm','Norma L2 dos updates locais')]:
 page();h(title);fig,axes=plt.subplots(3,3,figsize=(10,7.3),layout='constrained')
 for i,ds in enumerate(DS):
  for k,seed in enumerate(SEEDS):
   ax=axes[i,k]
   # per scenario share training but runtime timings may differ, aggregate client only for visualization, raw preserved.
   for sc in SC:
    q=cl[(cl.seed==seed)&(cl.dataset==ds)&(cl.scenario==sc)].groupby('round')[col].mean();ax.plot(q.index,q.values,label=sc,color=palette[SC.index(sc)])
   ax.set_title(names[ds]+f' / seed{seed}',fontsize=8);ax.set_xlabel('Rodada',fontsize=7);ax.tick_params(labelsize=7);ax.grid(alpha=.2)
 axes[0,0].legend(fontsize=6);chart(fig,'clientes_'+col,'Média dos cinco clientes por rodada/cenário; não representa execução paralela. Valores individuais completos disponíveis nos4050 registros anexos.',470)
# metrics symmetry and precision/hashes
page();h('Fechamento da cobertura e preservação')
p('Agora as três seeds possuem as mesmas famílias de demonstrações: métricas finais, curvas de validação, ganho temporal, CPU, checkpoints, diferenças contínuas, fidelidade da agregação e custos. Os valores podem variar; a simetria é de protocolo e cobertura, não de resultado.')
p('Lacunas comuns continuam explícitas: tempos internos históricos Hybrid não separados; setup completo de comunicação não serializado; captura de rede completa ausente; segregação física e ataques não avaliados. Nenhum piloto foi usado para preencher essas lacunas.')
p('Os resultados de qualidade finais anteriores não foram substituídos. A seed42 mantém seus valores; a inclusão das seeds123/2026 acrescenta cobertura. Todas as versões e fontes são preservadas. CPU e deltas complementares são comparados ao Baseline dentro da mesma seed.')
p('Fonte S08 SHA-256:<br/>'+hashlib.sha256(source.read_bytes()).hexdigest())
p('Este caderno é oficial quanto à proveniência dos runs. Os cálculos de auditoria são pós-processamentos dos modelos congelados, não novas execuções oficiais de treinamento e não evidência de resistência a ataques.')
PDF=R/'Complemento_Oficial_S08_Tres_Seeds.pdf'
def footer(c,d):c.setFont('DV',7);c.drawString(40,24,'Complemento oficial S08 • 06/10/2026');c.drawRightString(555,24,str(d.page))
SimpleDocTemplate(str(PDF),pagesize=(595.28,841.89),leftMargin=40,rightMargin=40,topMargin=38,bottomMargin=42,title='Complemento oficial S08: três seeds').build(story,onFirstPage=footer,onLaterPages=footer)
# cumulative preserves all V7 content; authoritative completion follows, prior scope limitation explicitly updated here.
base=fitz.open('caderno_oficial_v7/Caderno_Oficial_Resultados_V7_Download.pdf');supp=fitz.open(PDF);out=fitz.open();out.insert_pdf(base);offset=len(out);out.insert_pdf(supp)
toc=base.get_toc();toc.append([1,'Cobertura S08: três seeds completas',offset+1])
for i,pag in enumerate(supp):
 lines=pag.get_text().splitlines();title=lines[2] if len(lines)>2 else ''
 if title:toc.append([2,title,offset+i+1])
out.set_toc(toc);out.set_metadata({'title':'Caderno oficial V8 — cobertura equivalente de três seeds','author':'Geanderson Braga Lopes'});final=R/'Caderno_Oficial_Resultados_V8_Tres_Seeds.pdf';out.save(final,deflate=True)
# Coverage matrix and descriptive stats: allseeds same fields
coverage=pd.read_csv(S/'S08_FIELD_COVERAGE.csv').groupby(['seed','metric_group']).present.agg(['count','sum']);coverage.to_csv(D/'Matriz_Cobertura_Seeds.csv')
rec.groupby(['dataset','scenario','split']).agg({c:['count','mean','std','min','max'] for c in ['accuracy','precision','recall','f1','auroc','log_loss','brier_score','ece_10_bins']}).to_csv(D/'Estatisticas_Finais_Tres_Seeds.csv')
(D/'INDICE_FIGURAS_S08.json').write_text(json.dumps(figure_inventory,ensure_ascii=False,indent=2))
record={'version':'V8','s08_status':gate['status'],'checks':gate['checks_count'],'failed_checks':0,'official_runs':27,'official_rounds':810,'client_records':4050,'checkpoints':837,'final_evaluations':54,'continuous_comparisons':27,'historical_numerical_replacements':0,'v7_pages_preserved':len(base),'s08_start_page':offset+1,'total_pages':len(out),'new_figures':len(figure_inventory),'new_tables':len(table_inventory),'s08_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(R/'Registro_Atualizacao_V8.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
(R/'LEIA_PRIMEIRO.md').write_text('V8 cumulativa: toda a V7 preservada; o complemento S08 a partir da página'+str(offset+1)+' completa a cobertura das três seeds. A referência anterior de cobertura parcial é superada pelo S08 aprovado. Dados oficiais exclusivamente; sem números de pilotos. O pacote contém todos os dados/gráficos V7 e S08. Anexo de810 rodadas continua preservado. Os registros4050 de clientes e837 checkpoints estão em CSV.\n')
files=[final,R/'Registro_Atualizacao_V8.json',R/'LEIA_PRIMEIRO.md',PDF]
for folder in ['dados_S08','graficos_S08','fontes_S08']:files.extend(p for p in (R/folder).rglob('*') if p.is_file())
with zipfile.ZipFile(R/'Pacote_Oficial_Resultados_V8_Tres_Seeds.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(R)))
 for folder in ['dados','graficos','fontes']:
  for p in (Path('caderno_oficial_v7')/folder).rglob('*'):
   if p.is_file():z.write(p,'acervo_V7/'+str(p.relative_to('caderno_oficial_v7')))
 z.write('caderno_oficial_v7/Anexo_810_Rodadas_Oficiais.pdf','Anexo_810_Rodadas_Oficiais.pdf')
print(json.dumps(record,ensure_ascii=False))
