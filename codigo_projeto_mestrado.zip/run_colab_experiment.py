
import os
import sys

sys.path.append("/content/Mestrado-main")

from flhe.data.dahl import load_dahl
from flhe.fl.federated_runner import run_federated_training
from flhe.logging.experiment_logger import ExperimentLogger


def run_experiment(scenario):

    print(f"Running scenario: {scenario}")

    X_train, y_train, X_val, y_val = load_dahl()

    out_dir = f"results/{scenario}"
    os.makedirs(out_dir, exist_ok=True)

    logger = ExperimentLogger(out_dir)

    run_federated_training(
        scenario=scenario,
        X_train=X_train,
        y_train=y_train,
        X_val=X_val,
        y_val=y_val,
        rounds=20,        # <<< ALTERAÇÃO AQUI
        num_clients=5,
        seed=42,
        logger=logger
    )

    logger.flush()

    print(f"Finished scenario: {scenario}")
