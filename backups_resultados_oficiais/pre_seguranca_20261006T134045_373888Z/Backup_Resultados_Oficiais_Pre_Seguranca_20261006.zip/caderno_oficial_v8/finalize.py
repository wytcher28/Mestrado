from pathlib import Path
import fitz,json,zipfile
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
R=Path('caderno_oficial_v8');pdfmetrics.registerFont(TTFont('V8F','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));st=getSampleStyleSheet()
for x in st.byName.values():x.fontName='V8F'
st.add(ParagraphStyle(name='P8',fontName='V8F',fontSize=10,leading=14,spaceAfter=12))
story=[]
def p(x):story.append(Paragraph(x,st['P8']))
story.append(Paragraph('Caderno oficial de resultados — V8',st['Title']));p('Geanderson Braga Lopes • FT/Unicamp • 06/10/2026')
p('Edição cumulativa com cobertura equivalente das seeds42,123 e2026. Apenas a campanha oficial; pilotos permanecem fora das figuras, tabelas e estatísticas.')
p('O S08 completou as demonstrações que antes apareciam somente para seed42. Status: COVERAGE_APPROVED; 3.487 verificações registradas, zero falhas. Há270 rodadas,1.350 registros de clientes,18 avaliações finais e279 checkpoints por seed.')
p('Agora todas as seeds possuem curvas de qualidade e ganho temporal, CPU, checkpoints, diferenças contínuas, fidelidade numérica e custos. Valores anteriores preservados; nenhuma substituição numérica. Novos cálculos são auditoria/pós-processamento de modelos congelados, sem treinamento ou ajuste de modelo.')
p('<b>Organização:</b><br/>Páginas2–54: conteúdo oficial V7 preservado.<br/>Páginas55–89: complemento S08, com24 figuras e22 tabelas.<br/>Marcadores do PDF permitem navegação. As referências de cobertura parcial na seção histórica são superadas pelo S08 aprovado, sem apagar o histórico.')
p('<b>Limites comuns mantidos:</b> tempos internos históricos do Hybrid não separados; comunicação completa de setup/rede não medida; isolamento físico e ataques ainda não avaliados. Esses pontos não foram preenchidos com números de pilotos.')
p('O pacote inclui gráficos editáveis em SVG e PNG, CSVs, fontes S08 e acervo oficial V7, além do anexo das810 rodadas. O fechamento desta etapa é de cobertura e consistência dos resultados; não é prova de segurança.')
cover=R/'Abertura_Oficial_V8.pdf';SimpleDocTemplate(str(cover),pagesize=(595.28,841.89),leftMargin=42,rightMargin=42,topMargin=42,bottomMargin=42).build(story)
f=R/'Caderno_Oficial_Resultados_V8_Tres_Seeds.pdf';orig=fitz.open(f);out=fitz.open();c=fitz.open(cover);assert len(c)==1;out.insert_pdf(c);out.insert_pdf(orig);toc=[[1,'V8 — cobertura completa e organização',1]]+[[level,title,page+1] for level,title,page in orig.get_toc()];out.set_toc(toc);out.set_metadata({'title':'Caderno oficial V8 — cobertura equivalente de três seeds','author':'Geanderson Braga Lopes'});tmp=R/'V8_final.pdf';out.save(tmp,garbage=4,deflate=True);orig.close();out.close();tmp.replace(f)
record=json.loads((R/'Registro_Atualizacao_V8.json').read_text());record['s08_start_page']=55;record['total_pages']=89;record['v7_start_page']=2;(R/'Registro_Atualizacao_V8.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));(R/'LEIA_PRIMEIRO.md').write_text('V8: somente resultados oficiais. As três seeds têm igual cobertura de demonstrações. Conteúdo V7 preservado nas páginas2–54; S08 completo nas páginas55–89, com24 novas figuras e22 tabelas. Referências antigas a cobertura parcial são superadas pelo S08 aprovado. Pilotos não incluídos. Dados e figuras de V7 e S08 no pacote; anexo das810 rodadas preservado. Nenhum treinamento ou substituição numérica.\n')
# QA every page: finite rendered PDF, no overflow and prior content identical.
v=fitz.open(f);base=fitz.open('caderno_oficial_v7/Caderno_Oficial_Resultados_V7_Download.pdf');assert len(v)==89
for i,p in enumerate(base):assert p.get_text()==v[i+1].get_text()
for i,p in enumerate(v):
 for b in p.get_text('blocks'):assert b[0]>=25 and b[2]<575 and b[1]>=10 and b[3]<831,(i+1,b[:4])
 p.get_pixmap(matrix=fitz.Matrix(.1,.1))
for i in [0,54,55,74,82,87]:v[i].get_pixmap(matrix=fitz.Matrix(.5,.5)).save(R/f'qa_{i+1}.png')
files=[f,R/'Registro_Atualizacao_V8.json',R/'LEIA_PRIMEIRO.md',R/'Complemento_Oficial_S08_Tres_Seeds.pdf']
for folder in ['dados_S08','graficos_S08','fontes_S08']:files.extend(p for p in (R/folder).rglob('*') if p.is_file())
with zipfile.ZipFile(R/'Pacote_Oficial_Resultados_V8_Tres_Seeds.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(R)))
 for folder in ['dados','graficos','fontes']:
  for p in (Path('caderno_oficial_v7')/folder).rglob('*'):
   if p.is_file():z.write(p,'acervo_V7/'+str(p.relative_to('caderno_oficial_v7')))
 z.write('caderno_oficial_v7/Anexo_810_Rodadas_Oficiais.pdf','Anexo_810_Rodadas_Oficiais.pdf')
print('PASS:89 pages rendered, text in bounds, V7 preserved exactly, final package rebuilt.')
